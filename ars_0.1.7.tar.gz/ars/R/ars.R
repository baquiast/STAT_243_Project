#' Adaptive Rejection Sampler
#' @description
#' Adaptive Rejection Sampling from log-concave density functions
#' @param n sample size
#' @param f density to be sampled from; or log-density if log.transform = TRUE
#' @param ... arguments to be passed to f
#' @param fprima derivative of the density; or derivative of log-density if log.transform = TRUE. Adding derivative of the log-density makes computation faster
#' @param log.transform TRUE if f and fprima are log-density and derivative of log-density; log.transform=TRUE makes computation faster
#' @param x.start a vector of at least two starting points for the adaptive rejection sampling algorithm
#' @param domain domain on which to sample
#' @param plot.type one of "none", "bounds" or "acceptance". "none" is default and does not plot anything; "bounds" plots the computed upper and lower bonds; "acceptance" plots the upper and lower bonds, as well as the log-density (slower, to be used for testing)
#' @param pdf.name name of the density to appear on the title of the plot.
#' @return a sampled value from density
#' @details
#' The density has to be log-concave.
#'
#' Starting points are a vector of at least two points from which the adaptive rejection sampling algorithm will be performed. They are typically located at the extremum of the domain from which to sample.
#' If no starting points are given, but a domain is precised, the function will automatically define valid starting points within the domain boundaries.
#' If both starting points and domain are given, the sample will be done from the starting points. The starting points have to lie inside the domain.
#' If neither domain or starting points are given, the domain is by default from -infinity to inifinity.
#'
#' @references 
#' Gilks, W.R., P. Wild. (1992) Adaptive Rejection Sampling for Gibbs Sampling, Applied Statistics 41:337–348.
#' 
#' @examples
#' 
#' library(ars)
#' 
#' 
#' # Example1: Sample 1000 values from the Normal(0,1)
#' 
#' ## When starting points are given
#' mysample = ars(1000,dnorm,x.start=c(-2,2),plot.type="none")
#' mysample
#' hist(mysample)
#'  
#' ## When starting points are not given
#' mysample = ars(1000,dnorm,plot.type="none")
#' mysample
#' hist(mysample)
#'
#'
#' # Example2: Sample 20 values from the Beta(1,2) distribution
#' 
#' ## When starting points are given
#' par(mfrow=c(1,2))
#' mysample = ars(n = 20,dbeta,shape1=1,shape2=2,x.start=c(0.001,0.999),plot.type="bounds",pdf.name="Beta(1,2): ")
#' mysample = ars(n = 20,dbeta,shape1=1,shape2=2,x.start=c(0.001,0.999),plot.type="acceptance",pdf.name="Beta(1,2): ")
#' mysample
#' 
#' ## When starting points are not given
#' mysample = ars(n = 20,dbeta,shape1=1,shape2=2,plot.type="bounds",domain=c(0,1),pdf.name="Beta(1,2): ")
#' mysample = ars(n = 20,dbeta,shape1=1,shape2=2,plot.type="acceptance",domain=c(0,1),pdf.name="Beta(1,2): ")
#' mysample
#'
#'
#' # Example3: Sample 100 values from the user-defined log-concave density function
#' 
#' ## When log-density and derivative of log-density are given
#' 
#' par(mfrow=c(1,1))
#' h = function(x) {(-0.5)*x^2}
#' hprima = function(x) {-x}
#' mysample = ars(n=100,f=h,fprima=hprima,log.transform=TRUE,x.start=c(-4,4))
#' mysample
#' hist(mysample)



ars = function(n, f, ..., 
               fprima=NULL, 
               log.transform=FALSE, 
               x.start=NULL, 
               domain=c(-Inf,Inf), 
               plot.type = "none",
               pdf.name=""){ 
  
  ## Introduction:
  ## The objective of the adaptive rejection sampling is to efficiently generate samples 
  ## from computationally expensive functions. The function follows the theoretical 
  ## approach that Gilks and Wild (1992) introduced. We modularize the adaptive rejection 
  ## sampler into the five sub functions: 
  ## (a) checking log-concavity of the function
  ## (b) finding piecewise linear lower bound and upper bound
  ## (c) generating valid starting points
  ## (d) performing initialization, sampling and updating steps
  ## (e) plotting lower bounds and upper bounds.
  
  
  ## 0. Set seed to replicate results
  set.seed(100)

  ## 1. Generate h(x), log-density, and h'(x), 
  if(log.transform==TRUE){
    h = function(x){
      if(sum(is.na(f(x,...)))!=0){
        stop("The input density has negative values or too small values")
      }
      return(f(x,...))
    }  
  } else{
    h = function(x){
      if(sum(is.na(log(f(x,...))))!=0){
        stop("The input density has negative values")
      }
      return(log(f(x,...)))
    }
  }
  
  if(log.transform==TRUE){
    hprima = function(x){
      fprima(x)
    }
  } else {
    hprima = function(x){
      fprima(x)/f(x,...)
    }
  }
  
  ## 2. Generate valid starting points  
  x.start = gen.start(x.start,domain,h,fprima,hprima)
  
  ## 3. Check log-concavity at starting points
  if(is.function(fprima)){d.start=hprima(x.start)} else {d.start = grad(h,x.start)}
  is.local.concave(d.start)
  
  ## 4. Perform initialization, sampling and updating steps
  xhd.list = ars.step(x.start,h,fprima,hprima,n)
  x.out = xhd.list[[2]] 
    # vector of final sample that is obtained from the adaptive rejection sampler
  
  ## 5. Plot (1) lower bounds and upper bounds or (2) acceptance regions and rejection regions 
  x.vec = xhd.list[[1]][,1] # vector of starting points and x's rejected from the squeezing tests
  h.vec = xhd.list[[1]][,2] # h(x.vec)=log(f(x.vec))
  d.vec = xhd.list[[1]][,3] # h'(x.vec)
  
  if(plot.type == "bounds"){      # (1) Plot lower bounds and upper bounds
    boundary.plot(x.vec,h.vec,d.vec,h=FALSE,pdf.name)
  }
  if(plot.type == "acceptance"){  # (2) Plot acceptance regions and rejection regions
    boundary.plot(x.vec,h.vec,d.vec,h,pdf.name)
  }
  
  return(x.out)
}
