###############################################################################
###############################################################################
## List of the subfunctions
###############################################################################
## 1. is.local.concave()
## 2. lower(), upper()
## 3. gen.start()
## 4. ars.step()
## 5. boundary.plot()
###############################################################################


###############################################################################
## 1. is.local.concave()
###############################################################################

## 1-1. Introduction
## The is.local.concave() function checks the log-concavity of a given density 
## function. It checks whether derivatives of log-density at a vector of points
## decreases as x increases. We put this function at the end of the updating 
## step in the ars.step() function. We can thus catch non-log-concave cases
## (i.e. cases where upper bounds and lower bounds are not bounding the 
## log-densiy) as calculations proceed.

## 1-2. Input
## - d.vec: a vector of derivatives of log-density at a vector of points

## 1-3. Output
## - The function gives error message if it catches non-log-concave cases.

## 1-4. Code

is.local.concave = function(d.vec){ 
  if(!all.equal(d.vec,sort(d.vec,decreasing=TRUE))==TRUE){
    stop("Error: The distribution is not log concave!")
  }else{
    return("TRUE")
  }
}


###############################################################################
## 2. lower() and upper()
###############################################################################

## 2-1. Introcuction
## The lower() and upper() functions compute lower bounds and upper bounds. 
## The main function can generate samples efficiently as it uses upper bounds
## and lower bounds when performing initialzation, sampling and updating steps. 
## For example, it makes squeezing function from upper bound and uses it as 
## sampling probabilities. It also determines which samples to accept or reject 
## by computing lower bound and upper bound.

## 2-2. Input
## - x: a vector of points sampled out at the beginning of a sampling step.
## - x.vec: a vector of which elements are (1) starting points, (2) points 
##          rejected at the squeezing steps
## - h.vec: log(f(x.vec)), a vector of log-density at x.vec
## - d.vec: a vector of derivatives of log-density at x.vec 

## 2-3. Output
## - The lower(x, x.vec, h.vec) returns a vector of lower bounds at x
## - The upper(x, x.vec, h.vec, d.vec) returns a vector of upper bounds at x

## 2-4. Code

lower = function(x, x.vec, h.vec){
  z = sort(c(x, x.vec))
  l = match(x,z) - (1:length(x)) 
  return(((x.vec[l+1]-x) * h.vec[l] + (x-x.vec[l])*h.vec[l+1])/(x.vec[l+1]-x.vec[l]))
      # Return a vector of lower bounds at x 
}

upper = function(x, x.vec, h.vec, d.vec){
  z = sort(c(x,x.vec))
  l = match(x,z) - (1:length(x))
  return(pmin(h.vec[l] + (x-x.vec[l])*d.vec[l],
              h.vec[l+1] + (x-x.vec[l+1])*d.vec[l+1] , na.rm=FALSE))
      # Return a vector of upper bounds at x 
}


###############################################################################
## 3. gen.start()
###############################################################################

## 3-1. Introduction
## The gen.start() function generates valid starting points even when users do 
## not give starting points, by using domain boundaries. When log-density or 
## derivatives of log-density cannot be computed at the domain boundaries in R, 
## this function first set starting points as the points that are located close 
## to the boundaries and give numerical values of log-density and derivatives of 
## log-density. If the mod of the density within the two starting points is 
## very close to one of them, our function replaces the other point with a 
## point of which log-density is the average of the maximum log-density and 
## the log-density of that point. 

## 3-2. Input
## - x.start: a vector of given starting points
## - domain: a vector of two end points of which range we sample
## - h: log-density function
## - fprima: derivative of the density
## - hprima: deriavtive of the log-density

## 3-3. Output
## - x.start: a vector of starting points obtained from this function

## 3-4. Code

gen.start = function(x.start,domain,h,fprima,hprima) {
  # 1. When user gives starting values
  if(length(x.start)!=0) {
    # 1.1 Check if there is at least two unique starting values
    if(length(unique(x.start))<2){
      stop("At least two unique starting values are required")
    }
    # 1.2 Check if starting values are inside the domain
    if((sort(domain)[1] > min(x.start)) | (max(x.start) > sort(domain)[2])){
      stop("The starting values are outside the domain")
    }
    # 1.3 Check if starting values are differentiable
    if(sum(is.na(grad(h,x.start)))!=0){
      stop("The starting values are not differentiable")
    }
    x.start = sort(x.start)
  }else{ 
  # 2. When user does not give starting values
    # 2.1 Check if there is two unique domain boundaries
    if(length(domain)!=2 | length(unique(domain))!=2){ 
      stop("Invalid domain")
    }else{
      # 2.1.1 Sort domain in ascending order 
      if(domain[1]>domain[2]){
        domain = c(domain[2],domain[1])
      }
      # 2.1.2 Convert -Inf,Inf to some numerical value
      if(domain[1]==-Inf){
        domain[1] = -15
      }
      if(domain[2]==Inf){
        domain[2] = 15
      }
      
      # 2.1.3 Generate a vector of various proportions
      p1 = seq(0.1,0,l=10) 
      p2 = seq(10,0,l=10)
        # make two vectors of sequences
      p.vec1 = cumsum(exp(p1)/sum(exp(p1))) 
      p.vec2 = cumsum(exp(p2)/sum(exp(p2)))
        # use the exp() function and compute cumulative sum of proportions 
      p.vec = unique(sort(c(p.vec1,p.vec2,0.5*p.vec1,0.5*p.vec2)))
      p.vec = c(p.vec,1-p.vec)
      p.vec = p.vec[p.vec!=0 & p.vec!=1]
        # p.vec has very small values(e.g. 3.045505e-05) to 
        # large values(e.g. 0.9999695). We need this variety of p.vec
        # in order to make our function work for various distributions.
      
      x.start = domain
        # Set x.start as domain boundaries. 
      
        # We vectorized all the computations except for this part 
        # because it loops for only two times.
      for(i in 1:2) {
        x.temp1 = rep(NULL,length(p.vec))
        if(h(x.start[i])==Inf){
           # if h(x.start) has still is infinity, we try to move only a small
           # small amount, as we don't want to lose a large density. 
          x.temp1 = domain[i]-((-1)^(i))*min(1e-2,(domain[2]-domain[1]))*p.vec
           # set the first x that gives both valid h(x) and h'(x) as x.start
          x.temp1 = x.temp1[abs(h(x.temp1))!=Inf]
          x.start[i] = x.temp1[!is.na(grad(h,x.temp1))][1]
        }
        else if(h(x.start[i])==-Inf){
            # if h(x.start) has still is -infinity, we can move a bit.
          x.temp1 = domain[i] - ((-1)^(i))*(domain[2]-domain[1])*p.vec
            # set the first x that gives both valid h(x) and h'(x) as x.start
          x.temp1 = x.temp1[abs(h(x.temp1))!=Inf]
          x.start[i] = x.temp1[!is.na(grad(h,x.temp1))][1]
        }
        else {
            # check h'(x.start) even when h(x.start) is valid.
          if(!is.na(grad(h,x.start[i]))){
            x.start[i] = x.start[i] 
          }else{
            #  if h'(x.start) is invalid, we try to move only a small
            # small amount, as h(x.start) is valid. 
            x.temp1 = domain[i]-((-1)^(i))*min(1e-2,(domain[2]-domain[1]))*p.vec
            x.start[i] = x.temp1[!is.na(grad(h,x.temp1))][1]            
          }
        }
      }
      
        # Find x.mod that gives maximum h(x).
      x.mod = optimize(h,interval=x.start,maximum=TRUE)$maximum
        # compute the distance between x.mod and x.start
      x.diff = abs(x.start - x.mod)
        #  if x.mod is very close to one(e.g. x.start[1]) of two elements 
        # in x.start, replace the other element(e.g., x.start[2]) with a 
        # point of which h(x) is the average of maximum h(x) and 
        # h(x) of x.start[2]. Note that mimimum of h(x) within the range 
        # between x.start[1] and x.start[2] is same as h(x.start[2]).
      if((x.diff[1]/x.diff[2]) > 1e5 | (x.diff[2]/x.diff[1]) > 1e5) {
        A=optimize(h,interval=x.start,maximum=TRUE)$objective
        B=optimize(h,interval=x.start,maximum=FALSE)$objective
        k = function(x){h(x) - (A-(A-B)*0.5)}
        x.start1 = x.start[which.max(x.diff)]
        x.start[which.max(x.diff)] = uniroot(k,interval=c(x.mod,x.start1))$root
      }
    }
  }
  return(x.start)
    # return starting points obtained from this function. 
}


###############################################################################
## 4. ars.step()
###############################################################################

## 4-1. Introduction
## The objective of the ars.step() function is to extract the expected number 
## of samples of which distribution is statistically similar to the true 
## distribution. It carries out the three key steps of the adaptive rejection 
## sampling in a vectorized way. 
## - The initialization step evaluates h(x) at starting points.
## - The sampling step generates a vector of samples based on the upper bound. 
##   We keep points that pass the squeezing test, and evaluate h(x) at the 
##   remaining points. The procedure continues until it has generated the 
##   requested number of points. Vectorization makes the function fast.
## - The updating step computes h'(x) at the points that are rejected in the 
##   sampling step.

## 4-2. Input
## - x.start: a vector of starting points generated from the gen.start() function
## - h: log-density function
## - fprima: derivative of the density
## - hprima: deriavtive of the log-density
## - n: sample size

## 4-3. Output
## - list of xhd.mat and x.out
##   - xhd.mat: a matrix of x.vec, h.vec, d.vec
##     - x.vec: a vector of starting points and x's rejected from the squeezing tests
##     - h.vec: h(x.vec)
##     - d.vec: h'(x.vec)
##   - x.out: a vector of the final sample

## 4-4. Code

ars.step = function(x.start,h,fprima,hprima,n) {
  
  ## Initialization step
  x.out = NULL
  x.vec = sort(x.start)
  h.vec = h(x.vec)
  if(is.function(fprima)){d.vec=hprima(x.vec)} else {d.vec = grad(h,x.vec)}
  # Evaluate d(x), the derivative of h(x), of starting points    
  xhd.mat = cbind(x.vec,h.vec,d.vec)
  
  x.temp.start = x.vec[1]
  x.temp.end = x.vec[length(x.vec)]
  dx = (x.temp.end-x.temp.start)/(100000000*n)
  x.temp = seq(x.temp.start+dx, x.temp.end-dx,l=20*n)
  
  while(length(x.out) <= n){
    
    ## Sampling step
    u = runif(n-length(x.out),0,1)
      # Sample values from the uniform(0,1) distribution 
    
    x.cand = sample(x.temp,size=n-length(x.out),
                    prob=exp(upper(x.temp,x.vec,h.vec,d.vec)))
    x.cand = runif(n-length(x.out),x.cand-dx,x.cand+dx)
    x.cand = sort(x.cand)
      # Sample values from the s(x), squeezing function  
    
    ## Sampling step: (1) Squeezing test
      # Evaluate l(x) and u(x)
    x.cand.sq1 = x.cand[u <= exp(lower(x.cand,x.vec,h.vec)-
                                   upper(x.cand,x.vec,h.vec,d.vec))]
      # Accepted x.cand
    x.cand.sq0 = x.cand[!x.cand %in% x.cand.sq1]
    x.cand.sq0 = x.cand.sq0[!is.na(x.cand.sq0)] 
      # Rejected x.cand
    
    ## Sampling step: (2) Rejection test
    u.sq0 = u[which(x.cand %in% x.cand.sq0)]
    x.cand.re1 = x.cand.sq0[u.sq0 <= exp(h(x.cand.sq0) - 
                                           upper(x.cand.sq0,x.vec,h.vec,d.vec))] 
    x.cand.re1 = x.cand.re1[!is.na(x.cand.re1)]
      # Accepted x.cand.sq0
    
    x.out = append(x.out, c(x.cand.sq1, x.cand.re1))
      # Accepted samples
    if(length(x.out)==n) {break}
      # Stop the for loop if the number of samples is n
    
    ## Updating step
    h.cand.sq0 = h(x.cand.sq0)
      # Evaluate h(x) of samples rejected at the squeezing test
    
    if(is.function(fprima)){
      d.cand.sq0 = hprima(x.cand.sq0)
    }else{
      d.cand.sq0 = grad(h, x.cand.sq0)
    } # Evaluate d(x) of samples rejected at the squeezing test
    
    cand.mat = cbind(x.cand.sq0, h.cand.sq0, d.cand.sq0)
    
    xhd.mat = cbind(append(xhd.mat[,1],cand.mat[,1]),
                    append(xhd.mat[,2],cand.mat[,2]),
                    append(xhd.mat[,3],cand.mat[,3]))
    xhd.mat = xhd.mat[order(xhd.mat[,1]),]
    x.vec = xhd.mat[,1]
    h.vec = xhd.mat[,2]
    d.vec = xhd.mat[,3]    
    
    is.local.concave(d.vec)  
      # Check for log-concavity
  }
  return(list(xhd.mat,x.out))
}  


###############################################################################
## 5. boundary.plot()
###############################################################################

## 5-1. Introduction
## The boundary.plot() plots (1) upper bounds and lower bounds or 
## (2) acceptance regions and rejection regions.

## 5-2. Input
## - x: a vector of points sampled out at the beginning of a sampling step.
## - x.vec: a vector of which elements are (1) starting points, (2) points 
##          rejected at the squeezing steps
## - h.vec: log(f(x.vec)), a vector of log-density at x.vec
## - d.vec: a vector of derivatives of log-density at x.vec 
## - h: log-density; FALSE for plotting lower bounds and upper bounds; 
##      TRUE for plotting acceptance regions and rejection regions
## - pdf.name: name of the density to apper on the title of the plot

## 5-3. Output
## - Plot of (1) lower bounds and upper bounds or 
##           (2) acceptance regions and rejection regions

## 5-4. Code

boundary.plot = function(x.vec,h.vec,d.vec,h=FALSE,pdf.name){
  
  # Create upper bound
  nvec = length(x.vec)
  x.vals = seq(x.vec[1],x.vec[nvec],l=100)
  
  x.mat = cbind(x.vec[1:(nvec-1)],x.vec[2:nvec])
  h.mat = cbind(h.vec[1:(nvec-1)],h.vec[2:nvec])
  d.mat = cbind(d.vec[1:(nvec-1)],d.vec[2:nvec])
  x.center = (h.mat[,2]-h.mat[,1]-x.mat[,2]*d.mat[,2]+
                x.mat[,1]*d.mat[,1])/(d.mat[,1]-d.mat[,2])
  h.center = h.mat[,1] + d.mat[,1]*(x.center-x.mat[,1]) 
  x.corners = c(x.vec[1],x.center,x.vec[nvec])
  h.corners = c(h.vec[1],h.center,h.vec[nvec])
  
  # Plot
  if(is.function(h)){
    plot(h, xlim=c(x.vec[1],x.vec[nvec]), lwd =1, yaxt='n', ylab='', xlab="x",
         main =paste(pdf.name,"Acceptance and\nrejection regions of the log density"),
         cex.lab = 1.4)
    polygon(x.corners,h.corners,
            col="firebrick", border="firebrick")
    polygon(c(x.vals,x.vec[nvec],x.vec[1]),c(h(x.vals),min(h.vec),min(h.vec)),
            col="palegreen4",border="palegreen4") # acceptance region
    lines(x.corners,h.corners, lwd=1, col="firebrick")
    lines(x.vec,h.vec, lwd =1, col="grey10") # lower bound
    legend(x="topright", legend=c("Acceptance region", "Rejection region",
                                  "Lower bound"),
           col=c("palegreen4","firebrick","grey10"),
           pch=c(15,15,NA),lty=c(0,0,1), seg.len = 0.5, cex = 0.6)
  } else{
    plot(x.corners,h.corners, type = "l",lty =1, lwd=1, col="red", xlab="x",
         yaxt='n', ylab='', main=paste(pdf.name,"Upper and lower bounds\nof the log density"),
         cex.lab = 1.4)
    lines(x.vec,h.vec, lwd =1,col="black") # lower bound
    legend(x="topright",legend=c("Upper bound", "Lower bound"),
           col=c("black","red"), lty=c(1,1), cex = 0.6)
  }
}

###############################################################################
###############################################################################