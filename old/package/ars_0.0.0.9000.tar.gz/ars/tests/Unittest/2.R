###############################################################################
###############################################################################
## The unit test2 for the gen.start() functions
###############################################################################
## The gen.start() function is intended to give valid starting points even when
## users do not give starting points but give the domain ot a density function.
## The two end points of a given domains sometimes have numeric h(x) and h'(x). 
## But sometimes they give h(x) or h'(x) that cannot be evaluated in R. If end 
## points can be evaluated, we can just use the points as starting points. But
## if not, the gen.start() helps users to guess valid starting points from 
## given domains. We followed the algorithm of the function and computated
## by hand, and compared the results with the results that were obtained from
## the function. 

test.gen.start <- function() {
  x.start=NULL
  domain=c(-4,4)
  f=function(x) {log(dnorm(x))}
  domain=c(-1,1)
  checkEquals(gen.start(x.start,domain,f),c(-1,1),tolerance=10^-6)
  domain=c(-Inf,Inf)
  checkEquals(gen.start(x.start,domain,f),c(-15,15),tolerance=10^-6)
  
  f=function(x) {log(dexp(x,1))}
  domain=c(0,10)
  checkEquals(gen.start(x.start,domain,f), 
              c(0.000525368,5.000262758),tolerance=10^-6)
  domain=c(0,Inf)
  checkEquals(gen.start(x.start,domain,f), 
              c(0.000525368,7.500262796),tolerance=10^-6)
}

###############################################################################
###############################################################################