###############################################################################
###############################################################################
## The unit test3 for the ars.step() functions
###############################################################################
## The ars.step() function carries out the three key steps of the adaptive 
## rejection sampling: the initialization, sampling, and updating steps. Our
## objective of this function is to extract the expected number of samples that 
## represent true distributions. As the first formal tests show that our result 
## is statistically similar to the known truth, our interest in this unit test 
## is to check whether we get the expected number of samples. We tried the unit
## test for the standard distribution, Normal(mean=0, sd=1).

test.ars.step = function() {
  x.start <- c(-4,4)
  h = function(x) {log(dnorm(x,0,1))}
  fprima = NULL
  hprima = NULL
  n=10
  list <- ars.step(x.start,h,fprima,hprima,n)
  checkEquals(10,length(list[[2]]))
}

###############################################################################
###############################################################################