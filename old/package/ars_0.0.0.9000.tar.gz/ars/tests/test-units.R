###############################################################################
###############################################################################
## The file for running the unit tests
###############################################################################

source('ars.R') 
  # Find the file of the main function.

test.suite <- defineTestSuite("sub functions",
                              dirs = file.path("Unittest"),
                              testFileRegexp = '^\\d+\\.R')
  # Find the directory of the unit test codes.

test.result <- runTestSuite(test.suite)
  # Save the test results.

printTextProtocol(test.result)
  # Print the test results.

###############################################################################
###############################################################################