###############################################################################
###############################################################################
## List of the tests
###############################################################################
## 1. Formal tests of the overall function
## 2. Formal tests of the modular function for log-concavity checks
## 3. Unit tests of the modular functions
###############################################################################


###############################################################################
## 1. Formal tests of the overall function 
###############################################################################
## 1-1. The function for the tests
## The test_sample() function does the Wilcoxon Rank Sum Test and Kolmogorov
## -Smirov Test to compare the a sample from the adaptive rejection sampler to
## known samples (e.g., samples from the 'r' functions, such as rnorm). This 
## function passes both of the tests if they are accepted on a 5% significance 
## level. We applied the test to the results of the adaptive rejection sampling
## for the seven key log concave distributions, and try to confirm that our 
## adaptive rejection sampler works properly.

test_sample <- function(x,y){
  test_passed = TRUE
  wilcox_test = wilcox.test(x, y, 
                             alternative = c("two.sided", "less", "greater"),
                             mu = 0, paired = FALSE, exact = NULL, 
                             correct = TRUE, conf.int = FALSE, 
                             conf.level = 0.95)$p.value
  ks <- ks.test(x, y, alternative = "two.sided",exact = NULL)$p.value
  
  # Wilcoxon Rank Sum Test
  if(!(wilcox_test>0.05)) {
    test_passed <- FALSE
  }
  
  # Kolmogorov–Smirnov Test
  if(!(ks>0.05)) {
    test_passed <- FALSE
  }
  
  # Final message
  return(test_passed)
}

###############################################################################
## 1-2. List of the tested log-concave distributions 
## (a) Normal 
## (b) Gamma(if shape parameter>=1)
## (c) Beta(if both shape parameters>=1)
## (d) Exponential 
## (e) Chi Square(if df>=2)
## (f) Logistic 
## (g) Double Exponential(Laplace)
## (h) Uniform

###### (a) Normal distribution 

test_that("Normal(0,1)",{
  set.seed(100)
  par(mfrow=c(2,2))
  x = rnorm(n=100,mean=0,sd=1) # random sampling from the normal distribution 
  y = ars(n=100,dnorm,mean=0,sd=1,plot.type="bounds",
          pdf.name="Normal(0,1): ")  
  ars(n=100,dnorm,mean=0,sd=1,plot.type="acceptance",
          pdf.name="Normal(0,1): ")
  hist(x,main="Histogram of sample from\nrnorm(n=50)")
  hist(y,main="Histogram of sample from\nars(n=50, f=dnorm)")
  test_passed = test_sample(x,y)
  expect_true(test_passed)
  if(test_passed) {
    print(paste('[Formal Test1: Wilcoxon & KS] =>',
                ' Passed for Normal(mean=0,sd=1) on a 5% significance level.'))
  }
})

for(mean in -3:3){
  for(sd in 1:5){
    test_that("Normal",{
      set.seed(100)
      x = rnorm(n=100,mean,sd)
      y = ars(n=100,dnorm,mean,sd)
      test_passed = test_sample(x,y)
      expect_true(test_passed)
      if(test_passed) {
        print(paste('[Formal Test1: Wilcoxon & KS] => Passed for Normal(mean=',
              mean,', sd=',sd,') on a 5% significance level.'))
      }
    })
  }
}

##### (b) Gamma distribution 

test_that("Gamma(3,3)",{
  set.seed(100)
  par(mfrow=c(2,2))
  x = rgamma(n=50,shape=3,scale=3)
  y = ars(n=50,dgamma,shape=3,scale=3,domain=c(0,Inf),plot.type="bounds",
          pdf.name="Gamma(3,3): ")
  y = ars(n=50,dgamma,shape=3,scale=3,domain=c(0,Inf),plot.type="acceptance",
          pdf.name="Gamma(3,3): ")
  hist(x,main="Histogram from\nrgamma(n=50, shape=3, scale=3)")
  hist(y,main="Histogram from\nars(n=50, f=dgamma, 3, 3,domain=c(0,Inf)))")
  test_passed = test_sample(x,y)
  expect_true(test_passed)
  if(test_passed) {
    print(paste('[Formal Test1: Wilcoxon & KS] =>',
          ' Passed for Gamma(shape=3,scale=3) on a 5% significance level.'))
  }
})

for(shape in 1:5){
  for(scale in 1:5){
    test_that("Gamma",{
      set.seed(100)
      x = rgamma(n=100,shape,scale)
      y = ars(n=100,dgamma,shape,scale,x.start=c(0.001,4.5*shape))
      test_passed = test_sample(x,y)
      expect_true(test_passed)
      if(test_passed) {
        print(
          paste(
            '[Formal Test1: Wilcoxon & KS] => Passed for Gamma(shape=,',shape,
            ',scale=',scale,') on a 5% significance level.'))
      }
    })
  }
}

##### (c) Beta distribution 

test_that("Beta(2,3)",{
  set.seed(100)
  par(mfrow=c(2,2))
  x = rbeta(n=100,shape1=2,shape2=3)
  y = ars(n=100,dbeta,shape1=2,shape2=3,domain=c(0,1),plot.type="bounds"
          , pdf.name="Beta(2,3): ")
  ars(n=100,dbeta,shape1=2,shape2=3,domain=c(0,1),plot.type="acceptance"
      , pdf.name="Beta(2,3): ")
  hist(x,main="Histogram from\nrbeta(n=100, shape1=2, shape2=3)")
  hist(y,main="Histogram from\nars(n=100, f=dbeta, 2, 3, domain=c(0,1))")
  test_passed = test_sample(x,y)
  expect_true(test_passed)
  if(test_passed) {
    print(
      paste('[Formal Test1: Wilcoxon & KS] =>',
            ' Passed for Beta(shape1=2,shape2=3) on a 5% significance level.'))
  }
})

for(shape1 in 1:5){
  for(shape2 in 1:5){
    test_that("Beta",{
      x = rbeta(n=100,shape1,shape2)
      y = ars(n=100,dbeta,shape1,shape2,domain=c(0,1))
      test_passed = test_sample(x,y)
      expect_true(test_passed)
      if(test_passed) {
        print(paste('[Formal Test1: Wilcoxon & KS] =>',
                    ' Passed for Beta(shape1=',shape1,',shape2=',shape2,
                    ') on a 5% significance level.'))
      }
    })
  }
}

##### (d) Exponential distribution 

test_that("Exponential(2.5)",{
  set.seed(100)
  par(mfrow=c(2,2))
  x = rexp(n=100,rate=2.5)
  y = ars(n=100,dexp,rate=2.5,domain=c(0,Inf),plot.type="bounds"
          , pdf.name="Exponential(2.5): ")
  z = ars(n=100,dexp,rate=2.5,domain=c(0,Inf),plot.type="acceptance"
          , pdf.name="Exponential(2.5): ")
  hist(x,main="Histogram from\nrexp(n=100, rate=2.5)")
  hist(y,main="Histogram from\nars(n=100, f=dexp, 2.5, domain=c(0,Inf))")
  test_passed = test_sample(x,y)
  expect_true(test_passed)
  if(test_passed) {
    print(
      paste('[Formal Test1: Wilcoxon & KS] =>',
            ' Passed for Exponential(rate=2.5) on a 5% significance level.'))
  }
})

for(rate in 1:10) {
  test_that("Exponential",{
    set.seed(100)
    x = rexp(n=100,rate)
    y = ars(n=100,dexp,rate,x.start=c(0.001,2.5))
    test_passed = test_sample(x,y)
    expect_true(test_passed)
    if(test_passed) {
      print(paste('[Formal Test1: Wilcoxon & KS] =>',
                  ' Passed for Exponential(rate=',
                  rate,') on a 5% significance level.'))
    }
  })
}

##### (e) Chi Square distribution 

for(df in 2:20) {
  test_that("Chi",{
    set.seed(100)
    x = rchisq(n=100,df)
    y = ars(n=100,dchisq,df,x.start=c(0.001,30))
    test_passed = test_sample(x,y)
    expect_true(test_passed)
    if(test_passed) {
      print(paste('[Formal Test1: Wilcoxon & KS] =>',
                  ' Passed for Chi(df=',df,') on a 5% significance level.'))
    }
  })
}

##### (f) Logistic distribution 

test_that("Logistic(2,1)",{
  set.seed(100)
  x = rlogis(n=100, location=2, scale=1)
  y = ars(n=100, f=dlogis, location=2, scale=1, plot.type="bounds"
          , pdf.name="Logistic(2,1): ")
  z = ars(n=100, f=dlogis, location=2, scale=1, plot.type="acceptance"
          , pdf.name="Logistic(2,1): ")
  hist(x,main="Histogram of sample from\nrlogis(n=100, location=2, scale=1)")
  hist(y,main="Histogram of sample from\nars(n=100, f=dlogis, 2, 1)")
  test_passed = test_sample(x,y)
  expect_true(test_passed)
  if(test_passed) {
    print
    (paste('[Formal Test1: Wilcoxon & KS] =>',
     ' Passed for Logistic(2,1) on a 5% significance level.'))
  }
})

for(location in -3:3){
  for(scale in 1:5){
    test_that("Logistic(0,1)",{
      set.seed(100)
      x = rlogis(n=100, location, scale)
      y = ars(n=100, f=dlogis, location, scale)
      test_passed = test_sample(x,y)
      expect_true(test_passed)
      if(test_passed) {
        print(paste('[Formal Test1: Wilcoxon & KS] =>',
                    ' Passed for Logistic(location=,',location,',scale=',scale,
                    ') on a 5% significance level.'))
      }
    })
  }
}

##### (g) Double Exponential distribution 

library(smoothmest)

for(mu in -3:3){
  for(lambda in 1:5){
    test_that("Double Exponential",{
      set.seed(100)
      x = rdoublex(n=100,  mu, lambda)
      y = ars(n=100, f=ddoublex, mu, lambda)
      test_passed = test_sample(x,y)
      expect_true(test_passed)
      if(test_passed) {
        print(
        paste('[Formal Test1: Wilcoxon & KS] =>',
              ' Passed for Double Exponenetial(mu=',mu,',lambda=',lambda,
              ') on a 5% significance level.'))
      }
    })
  }
}

###### (h) Uniform distribution

for(min in seq(-5,-1,1)){
  for(max in seq(1,5,1)){
    test_that("Unif",{
      set.seed(100)
      x = runif(n=100,min,max)
      y = ars(n=100,dunif,min,max,domain=c(min,max))
      test_passed = test_sample(x,y)
      expect_true(test_passed)
      if(test_passed) {
        print(paste('[Formal Test1: Wilcoxon & KS] =>',
              ' Passed for Unif(min=',min,',max=',max,
              ') on a 5% significance level.'))
      }
    })
  }
}
###############################################################################


###############################################################################
## 2. Formal tests of the modular function for log-concavity checks 
###############################################################################
## The is.local.concave() functions is intended to check the log-concavity of 
## density functions. The is.local.concave() function checks whether the 
## derivatives of log density decreases as x increases. This is the same as 
## checking whether a log density function lies between upper and lower bounds. 
## We tested the function with seven log-concave distributions(i.e., normal, 
## gamma, beta, exponenetial, chisquare, logistic, double exponential) and 
## the three non-log-concave distributions(i.e., Student's t, F, Cauchy).

##### (a) Log-concave: Normal distribution 

test_that("Formal Test2 for Normal",{
  h = function(x) {log(dnorm(x))}
  set.seed(100)
  x.vec <- sort(runif(10,-5,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print(
    '[Formal Test2: is.local.concave()] => Passed for Normal.')
  }  
})

##### (b) Log-concave: Gamma distribution 

test_that("Formal Test2 for Gamma",{
  h = function(x) {log(dgamma(x,shape=3,scale=3))}
  set.seed(100)
  x.vec <- sort(runif(10,0.1,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print(
    '[Formal Test2: is.local.concave()] => Passed for Gamma.')
  }  
})

##### (c) Log-concave: Beta distribution 

test_that("Formal Test2 for Beta",{
  h = function(x) {log(dbeta(x,shape1=2,shape2=3))}
  set.seed(100)
  x.vec <- sort(runif(10,0.1,0.9))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print(
    '[Formal Test2: is.local.concave()] => Passed for Beta.')
  }  
})

##### (d) Log-concave: Exponential distribution 

test_that("Formal Test2 for Exponential",{
  h = function(x) {log(dexp(x,rate=2.5))}
  set.seed(100)
  x.vec <- sort(runif(10,0.1,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print(
    '[Formal Test2: is.local.concave()] => Passed for Exponential.')
  }  
})

##### (e) Log-concave: Chi Square distribution 

test_that("Formal Test2 for Chi",{
  h = function(x) {log(dchisq(x,df=2))}
  set.seed(100)
  x.vec <- sort(runif(10,0.1,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print('[Formal Test2: is.local.concave()] => Passed for Chi Square.')
  }  
})

##### (f) Log-concave: Logistic distribution 

test_that("Formal Test2 for Logistic",{
  h = function(x) {log(dlogis(x,location=2,scale=1))}
  set.seed(100)
  x.vec <- sort(runif(10,-5,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print('[Formal Test2: is.local.concave()] => Passed for Logistic.')
  }  
})

##### (g) Log-concave: Double Exponential distribution 

test_that("Formal Test2 for Double Exponential",{
  h = function(x) {log(ddoublex(x,mu=0,lambda=1))}
  set.seed(100)
  x.vec <- sort(runif(10,-5,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkEquals(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print(
      '[Formal Test2: is.local.concave()] => Passed for Double Exponential.')
  }  
})

##### (h) Non-log-concave: Student's t distribution

test_that("Formal Test2 for Student's t",{
  h = function(x) {log(dt(x,df=2))}
  set.seed(100)
  x.vec <- sort(runif(10,-5,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkException(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print("[Formal Test2: is.local.concave()] => Failed for Student's t.")
  }  
})

##### (i) Non-log-concave: F distribution

test_that("Formal Test2 for F",{
  h = function(x) {log(df(x,df1=1, df2=5))}
  set.seed(100)
  x.vec <- sort(runif(10,0.1,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkException(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print("[Formal Test2: is.local.concave()] => Failed for F distribution.")
  }  
})

##### (j) Non-log-concave: Cauchy distribution

test_that("Formal Test2 for Cauchy",{
  h = function(x) {log(dcauchy(x,location=1,scale=0.5))}
  set.seed(100)
  x.vec <- sort(runif(10,-5,5))
  d.vec <- grad(h,x.vec)
  test_passed = checkException(is.local.concave(d.vec),"TRUE")
  expect_true(test_passed)
  if(test_passed) {
    print("[Formal Test2: is.local.concave()] => Failed for Cauchy.")
  }  
})
###############################################################################


###############################################################################
## 3. The unit tests of the modular functions
###############################################################################
## We first used the testthat pacakge to check the accuracy of the computations 
## of the individual modular functions. We then rechecked the similar codes 
## by using the RUnit package. Users can run this test using the code as below.
## library(RUnit)
## test_package('ars','units')
###############################################################################
## 3-1. is.local.concave() function
## The is.local.concave() function was tested at the second formal tests. This
## function does not need additional checks for the accuracy of computations, 
## as this function only uses the built-in grad() function to take derivatives.

###############################################################################
## 3-2. lower() and upper() functions 
## The lower() and upper() functions are intended to compute the values of the
## lower and upper bounds for a given vector of points. The first unit tests
## check the accuracy of computations of the lower() and upper() functions. 
## We used the fact that, for the points that are selected and used to set the 
## upper and lower bounds(i.e., x.vec), l(x.vec) = h(x.vec)= u(x.vec). The two
## tests below check these equality and thus proves the validity of these two
## functions.

##### (a) lower() function

test_that("Unit test1: lower bound",{
  x.vec <- c(-4,-1.091335,0,1.548574,4)
  h.vec <- c(-8.9189385,-1.5144445,-0.9189385,-2.1179792,-8.9189385)
  test_passed = 
    (sum(checkEquals(lower(1.548574,x.vec,h.vec),-2.117979,tolerance=10^-6) + 
         checkEquals(lower(-1.091335,x.vec,h.vec),-1.514444,tolerance=10^-6) +
         checkEquals(lower(0,x.vec,h.vec),-0.9189385,tolerance=10^-6) + 
         checkEquals(lower(4,x.vec,h.vec),-8.9189385,tolerance=10^-6) + 
         checkEquals(lower(-2,x.vec,h.vec),-3.827604,tolerance=10^-6) + 
         checkEquals(lower(2,x.vec,h.vec),-3.370365,tolerance=10^-6)) == 6)
  if(test_passed){
    print(
    "[Unit Test1: lower()] => Passed. Each computation is accurate.")
  }
})

##### (b) upper() function

test_that("Unit Test1: upper()",{
  x.vec <- c(-4,-1.091335,0,1.548574,4)
  h.vec <- c(8.9189385,-1.5144445,-0.9189385,-2.1179792,-8.9189385)
  d.vec <- c(4,1.091335,0,-1.548574,-4)
  test_passed = 
   (sum(
    checkEquals(upper(1.548574,x.vec,h.vec,d.vec),-2.117979,tolerance=10^-6) + 
    checkEquals(upper(-1.091335,x.vec,h.vec,d.vec),-1.514444,tolerance=10^-6) + 
    checkEquals(upper(0,x.vec,h.vec,d.vec),-0.918939,tolerance=10^-6) + 
    checkEquals(upper(4,x.vec,h.vec,d.vec),-8.918939,tolerance=10^-6) + 
    checkEquals(upper(-2,x.vec,h.vec,d.vec),-2.506102,tolerance=10^-6) + 
    checkEquals(upper(2,x.vec,h.vec,d.vec),-2.817046,tolerance=10^-6)) == 6)
  if(test_passed){
    print(
    "[Unit Test1: upper()] => Passed. Each computation is accurate.")
  }
})

###############################################################################
## 3-3. gen.start() function
## The gen.start() function is intended to give valid starting points even when
## users do not give starting points but give the domain ot a density function.
## The two end points of a given domains sometimes have numeric h(x) and h'(x). 
## But sometimes they give h(x) or h'(x) that cannot be evaluated in R. If end 
## points can be evaluated, we can just use the points as starting points. But
## if not, the gen.start() helps users to guess valid starting points from 
## given domains. We followed the algorithm of the function and computed
## by hand, and compared the results with the results that were obtained from
## the function. 

##### (a) Normal distribution

test_that("Unit Test2 for Normal",{
  h=function(x) {log(dnorm(x))}
  x.start=NULL
  domain=c(-1,1)
  test_passed = checkEquals(gen.start(x.start,domain,h),c(-1,1),
                            tolerance=10^-6)
  if(test_passed){
    print(
      paste("[Unit Test2: gen.start()] => Passed for Normal(mean=0,sd=1).",
        " The function gives the expected starting points",
        " when starting points aren't given and domain is (-1,1).",
        " Each computation carried out for the function is accurate."))
  }
})

test_that("Unit Test2 for Normal",{
  h=function(x) {log(dnorm(x))}
  x.start=NULL
  domain=c(-Inf,Inf)
  test_passed = checkEquals(gen.start(x.start,domain,h),
                            c(-15,15),tolerance=10^-6)
  if(test_passed){
    print(
     paste("[Unit Test2: gen.start()] => Passed for Normal(mean=0,sd=1).",
      " The function gives the expected starting points",
      " when starting points aren't given and domain is (-Inf,Inf).",
      " Each computation carried out for the function is accurate."))
  }
})

##### (b) Exponential distribution

test_that("Unit Test2 for Exponential",{
  h=function(x) {log(dexp(x))}
  x.start=NULL
  domain=c(0,10)
  test_passed = checkEquals(gen.start(x.start,domain,h), 
                            c(0.000525368,5.000262758),tolerance=10^-6)
  if(test_passed){
    print(
      paste("[Unit Test2: gen.start()] => Passed for Exponential(rate=1).",
       " The function gives the expected starting points",
       " when starting points aren't given and domain is (-1,1).",
       " Each computation carried out for the function is accurate."))
  }
})

test_that("Unit Test2 for Exponential",{
  h=function(x) {log(dexp(x))}
  x.start=NULL
  domain=c(0,Inf)
  test_passed = checkEquals(gen.start(x.start,domain,h),
                            c(0.000525368,7.500262796),tolerance=10^-6)
  if(test_passed){
    print(
      paste("[Unit Test2: gen.start()] => Passed for Exponential(rate=1).",
        " The function gives the expected starting points",
        " when starting points aren't given and domain is (0,Inf).",
        " Each computation carried out for the function is accurate."))
  }
})

###############################################################################
## 3-4. ars.step() function
## The ars.step() function carries out the three key steps of the adaptive 
## rejection sampling: the initialization, sampling, and updating steps. Our
## objective of this function is to extract the expected number of samples that 
## represent true distributions. As the first formal tests show that our result 
## is statistically similar to the known truth, our interest in this unit test 
## is to check whether we get the expected number of samples. We tried the unit
## test for the standard distribution, Normal(mean=0, sd=1).

test_that("Unit Test3",{
  x.start <- c(-4,4)
  h = function(x) {log(dnorm(x,0,1))}
  fprima = NULL
  hprima = NULL
  n=10
  list <- ars.step(x.start,h,fprima,hprima,n)
  test_passed = checkEquals(10,length(list[[2]]))
  if(test_passed){
    print(paste("[Unit Test3: ars.step()] => Passed for Normal(mean=0, sd=1),",
          " The function gives the expected number of samples."))
  }
})

###############################################################################
## 3-5. boundary.plot() function
## The boundary.plot() function is used to draw the two plots: (1) The plot for 
## upper and lower bounds of the given log density and (2) the plot for the
## acceptance regions of the log density. We did not try any unit test for this 
## function as the main purpose of the function is to give informative plots
## and because this function does not carry out any complicated computations.

###############################################################################
###############################################################################