###############################################################################
###############################################################################
## The unit test1 for the lower() and upper() functions
###############################################################################
## The lower() and upper() functions are intended to compute the values of the
## lower and upper bounds for a given vector of points. The first and second unit 
## tests check the accuracy of computations of the lower() and upper() functions. 
## We used the fact that, for the points that are selected and used to set the 
## upper and lower bounds(i.e., x.vec), l(x.vec) = h(x.vec)= u(x.vec). The two
## tests below check these equality and thus proves the validity of these two
## functions.

test.lower <- function() {
  x.vec <- c(-4,-1.091335,0,1.548574,4)
  h.vec <- c(-8.9189385,-1.5144445,-0.9189385,-2.1179792,-8.9189385)
  checkEquals(lower(1.548574,x.vec,h.vec),-2.117979,tolerance=10^-6)
  checkEquals(lower(-1.091335,x.vec,h.vec),-1.514444,tolerance=10^-6)
  checkEquals(lower(0,x.vec,h.vec),-0.9189385,tolerance=10^-6)
  checkEquals(lower(4,x.vec,h.vec),-8.9189385,tolerance=10^-6)
  checkEquals(lower(-2,x.vec,h.vec),-3.827604,tolerance=10^-6)
  checkEquals(lower(2,x.vec,h.vec),-3.370365,tolerance=10^-6)
}

test.upper <- function() {
  x.vec <- c(-4,-1.091335,0,1.548574,4)
  h.vec <- c(8.9189385,-1.5144445,-0.9189385,-2.1179792,-8.9189385)
  d.vec <- c(4,1.091335,0,-1.548574,-4)
  checkEquals(upper(1.548574,x.vec,h.vec,d.vec),-2.117979,tolerance=10^-6)
  checkEquals(upper(-1.091335,x.vec,h.vec,d.vec),-1.514444,tolerance=10^-6)
  checkEquals(upper(0,x.vec,h.vec,d.vec),-0.918939,tolerance=10^-6)
  checkEquals(upper(4,x.vec,h.vec,d.vec),-8.918939,tolerance=10^-6)
  checkEquals(upper(-2,x.vec,h.vec,d.vec),-2.506102,tolerance=10^-6)
  checkEquals(upper(2,x.vec,h.vec,d.vec),-2.817046,tolerance=10^-6)
}

###############################################################################
###############################################################################